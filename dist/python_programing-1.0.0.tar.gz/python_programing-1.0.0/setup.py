from setuptools import setup

setup(
    name='python_programing',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='',
    license='free',
    author='saito',
    author_email='saima.ptw88@gmail.com',
    description=''
)
