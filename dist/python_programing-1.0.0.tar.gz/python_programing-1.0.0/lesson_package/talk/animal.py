from lesson_package.tools import utils

def sing():
    return '4raopiyh898afhpuo;hga'

def cry():
    return utils.say_twice('09iou90avih@r8ew:jk')